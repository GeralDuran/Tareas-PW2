//Creamos la tabla del 7 

let numero = 0;

 while(numero < 10){
    numero++;
    console.log("7 X "+numero+" = "+(numero*7));
    
 }
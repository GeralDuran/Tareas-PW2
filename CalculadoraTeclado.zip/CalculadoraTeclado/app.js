// FORMULARIO
document.getElementById("calculadora-form").addEventListener("submit", function(event) {

    event.preventDefault();

    let numero1 = parseFloat(document.getElementById("num1").value.trim());
    let numero2 = parseFloat(document.getElementById("num2").value.trim());
    let operador = document.getElementById("operador").value;

    let resultado;

    switch (operador) {
        case "sum":
            resultado = numero1 + numero2;
            break;
        case "rest":
            resultado = numero1 - numero2;
            break;
        case "mul":
            resultado = numero1 * numero2;
            break;
        case "div":
            if (numero2 !== 0) {
                resultado = numero1 / numero2;
            } else {
                resultado = "Error: División por cero";
            }
            break;
        default:
            resultado = "Operador no válido";
    }

    document.getElementById("resultado").textContent = resultado;
});


// CALCULADORA POR BOTONES
function agregarPantalla(value) {
    document.getElementById("pantalla").value += value;
}

function limpiarPantalla() {
    document.getElementById("pantalla").value = "";
}

function calcularResultado() {
    try {
        let resultado = eval(document.getElementById("pantalla").value);
        document.getElementById("pantalla").value = resultado;
    } catch (error) {
        document.getElementById("pantalla").value = "Error";
    }
}
// carrito
const carrito = [];

// clase producto
class Producto {
    constructor(nombre, precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
}

// agregar producto
function agregarProducto(carrito, producto, cantidad) {

    //COMPARA NOMBRE Y PRECIO
    const indice = carrito.findIndex((item) =>
        item.producto.nombre === producto.nombre &&
        item.producto.precio === producto.precio
    );

    if (indice !== -1) {
        // mismo nombre y mismo precio → suma cantidad
        carrito[indice].cantidad += cantidad;
    } else {
        // mismo nombre pero diferente precio → lo agrega aparte 
        carrito.push({ producto, cantidad });
    }

    mostrarCarrito(carrito);
}

// mostrar carrito
function mostrarCarrito(carrito) {
    const listaCarrito = document.getElementById("carrito");
    listaCarrito.innerHTML = "";

    let total = 0;

    carrito.forEach((item, index) => {
        const li = document.createElement("li");

        const subtotal = item.producto.precio * item.cantidad;
        total += subtotal;

        li.innerHTML = `
            ${item.producto.nombre} - $${item.producto.precio} x ${item.cantidad}
            = $${subtotal.toFixed(2)}
            <button onclick="eliminarProducto(${index})">❌</button>
        `;

        listaCarrito.appendChild(li);
    });

    // mostrar total
    const totalLi = document.createElement("li");
    totalLi.innerHTML = `<strong>Total: $${total.toFixed(2)}</strong>`;
    listaCarrito.appendChild(totalLi);
}

// eliminar producto 
function eliminarProducto(index) {
    carrito.splice(index, 1);
    mostrarCarrito(carrito);
}

// evento formulario
document.getElementById("formulario").addEventListener('submit', function (event) {
    event.preventDefault();

    const nombreProducto = document.getElementById("nombre").value.trim();
    const precioProducto = parseFloat(document.getElementById("precio").value);
    const cantidadProducto = parseInt(document.getElementById("cantidad").value);

    const producto = new Producto(nombreProducto, precioProducto);

    agregarProducto(carrito, producto, cantidadProducto);

    document.getElementById("formulario").reset();
});
// Variables
const form = document.getElementById('formUsuario');
const tabla = document.getElementById('tablaUsuarios');
const inputArchivo = document.getElementById('importarJSON');
const descargarBtn = document.getElementById('descargarBtn');

// Cargar desde localStorage
let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

// Generar ID
function generarID() {
    return usuarios.length > 0 
        ? Math.max(...usuarios.map(u => u.id)) + 1 
        : 1;
}

// Guardar en localStorage
function guardarStorage() {
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}

// EVENTO FORMULARIO
form.addEventListener('submit', function (e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value.trim();
    const correo = document.getElementById('correo').value.trim();

    usuarios.push({
        id: generarID(),
        nombre,
        correo
    });

    guardarStorage();
    mostrarUsuarios();
    form.reset();
});

// MOSTRAR USUARIOS
function mostrarUsuarios() {
    tabla.innerHTML = "";

    usuarios.forEach((user, index) => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${user.id}</td>

            <td contenteditable="true"
                onblur="editarCampo(${index}, 'nombre', this.innerText)">
                ${user.nombre}
            </td>

            <td contenteditable="true"
                onblur="editarCampo(${index}, 'correo', this.innerText)">
                ${user.correo}
            </td>

            <td>
                <button onclick="eliminarUsuario(${index})">Eliminar</button>
            </td>
        `;

        tabla.appendChild(row);
    });
}

// EDICIÓN 
function editarCampo(index, campo, valor) {
    usuarios[index][campo] = valor.trim();
    guardarStorage(); // guardar automáticamente
}

// ELIMINAR
function eliminarUsuario(index) {
    if (confirm("¿Eliminar usuario?")) {
        usuarios.splice(index, 1);
        guardarStorage();
        mostrarUsuarios();
    }
}

// IMPORTAR JSON
inputArchivo.addEventListener('change', function (e) {
    const archivo = e.target.files[0];
    const lector = new FileReader();

    lector.onload = function (e) {
        try {
            const datos = JSON.parse(e.target.result);

            if (Array.isArray(datos)) {
                usuarios = datos;
                guardarStorage();
                mostrarUsuarios();
            } else {
                alert("El JSON no es válido");
            }
        } catch (error) {
            alert("Error al leer el archivo");
        }
    };

    lector.readAsText(archivo);
});

// DESCARGAR JSON
descargarBtn.addEventListener('click', function () {
    const blob = new Blob([JSON.stringify(usuarios, null, 2)], {
        type: 'application/json'
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');

    a.href = url;
    a.download = 'usuarios.json';
    a.click();

    URL.revokeObjectURL(url);
});

// INICIALIZAR
mostrarUsuarios();
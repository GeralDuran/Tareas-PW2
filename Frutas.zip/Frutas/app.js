const frutas = [];

let continuar = true;

while (continuar) {
    let fruta = prompt("Feria de frutas \n¿Qué fruta quieres?");

    // Validar que no esté vacío o cancelado
    if (fruta && fruta.trim() !== "") {
        frutas.push(fruta.trim());
    } else {
        alert(" No ingresaste una fruta válida");
    }

    continuar = confirm("¿Quieres agregar otra fruta?");
}

// Mostrar resultados
if (frutas.length > 0) {
    console.log(" Usted compró:");

    frutas.forEach((fruta, i) => {
        console.log(`${i + 1}. ${fruta}`);
    });

} else {
    console.log("No se compraron frutas ");
}
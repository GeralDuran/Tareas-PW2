//Creamos el metodo switch para imprimir los dias de la semana 

var dia = parseInt( prompt("Ingresa numero de la semana (Lunes 0 ...)"));

switch(dia){
    case 0:
        console.log("Lunes");
    break;

    case 1: 
    console.log("Martes");
    break;

    case 2: 
    console.log("Miercoles");
    break;

    case 3: 
    console.log("Jueves");
    break;

    case 4: 
    console.log("Viernes");
    break;

    case 5: 
    console.log("Sabado");
    break;

    case 6: 
    console.log("Domingo");
    break;
}
let nombres = [];

function agregarNombre(){
    let nombre = prompt("Ingresa el nombre:");

    if(nombre && nombre.trim() !== ""){
        nombres.push(nombre.trim());
        alert("Nombre agregado correctamente");
    }else{
        alert("El nombre no puede estar vacío");
    }
}

function mostrarNombres(){
    if(nombres.length === 0){
        alert("No hay nombres en el arreglo");
        return;
    }

    let mensaje = "Lista de nombres:\n";
    nombres.forEach((nombre, i) => {
        mensaje += (i + 1) + ".- " + nombre + "\n";
    });

    alert(mensaje);
}

function eliminarNombre(){
    if(nombres.length === 0){
        alert("No hay nombres para eliminar");
        return;
    }

    mostrarNombres();
    let index = Number(prompt("Ingresa el número del nombre a eliminar:"));

    if(!isNaN(index) && index >= 1 && index <= nombres.length){
        nombres.splice(index - 1, 1);
        alert("Nombre eliminado correctamente");
    }else{
        alert("Opción inválida");
    }
}

function buscarNombre(){
    let nombre = prompt("Ingresa el nombre a buscar:");

    if(!nombre || nombre.trim() === ""){
        alert("Nombre inválido");
        return;
    }

    if(nombres.includes(nombre.trim())){
        alert("El nombre sí está en la lista");
    }else{
        alert("El nombre no está en la lista");
    }
}

function menuNombres(){
    let opcion;

    do{
        opcion = prompt(
            "MENÚ DE NOMBRES\n" +
            "1.- Agregar\n" +
            "2.- Mostrar\n" +
            "3.- Eliminar\n" +
            "4.- Buscar\n" +
            "5.- Salir\n" +
            "Elige una opción:"
        );

        switch(opcion){
            case "1": agregarNombre(); break;
            case "2": mostrarNombres(); break;
            case "3": eliminarNombre(); break;
            case "4": buscarNombre(); break;
            case "5": alert("Saliendo..."); break;
            default: alert("Opción inválida");
        }

    }while(opcion !== "5");
}

//menuNombres();
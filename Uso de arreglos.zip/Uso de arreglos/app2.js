function menuCarrito(){

    let productos = [
        {nombre: 'camisa',   precio: 300},
        {nombre: 'pantalon', precio: 550},
        {nombre: 'zapatos',  precio: 750},
        {nombre: 'sombrero', precio: 550},
        {nombre: 'tenis',    precio: 1200}
    ];

    let carrito = [];

    function mostrarMenu(){
        let menu = "Seleccione un producto:\n";

        productos.forEach((p, i) => {
            menu += (i + 1) + ".- " + p.nombre + " - $" + p.precio + "\n";
        });

        menu += (productos.length + 1) + ".- Ver carrito y total\n";
        menu += (productos.length + 2) + ".- Salir\n";

        return menu;
    }

    function agregarAlCarrito(index){
        carrito.push(productos[index]);
        alert("Producto agregado al carrito");
    }

    function mostrarCarrito(){
        if(carrito.length === 0){
            alert("El carrito está vacío");
            return;
        }

        let mensaje = "Carrito:\n";
        let total = 0;

        carrito.forEach((p, i) => {
            mensaje += (i + 1) + ".- " + p.nombre + " - $" + p.precio + "\n";
            total += p.precio;
        });

        mensaje += "\nTotal: $" + total;

        alert(mensaje);
    }

    let opcion;

    do{
        opcion = Number(prompt(mostrarMenu()));

        if(opcion >= 1 && opcion <= productos.length){
            agregarAlCarrito(opcion - 1);
        }
        else if(opcion === productos.length + 1){
            mostrarCarrito();
        }

    }while(opcion !== productos.length + 2);

    alert("Gracias por su compra");
}
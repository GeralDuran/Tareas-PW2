function generarListas(){
    let numero = parseInt(document.getElementById("numero").value);
    let contenedor = document.getElementById("contenedor");

    contenedor.innerHTML = ""; // limpiar contenido previo

    if(isNaN(numero) || numero <= 0){
        alert("Ingresa un número válido");
        return;
    }

    for(let i = 1; i <= numero; i++){
        let titulo = document.createElement("h3");
        titulo.textContent = "Lista " + i;

        let lista = document.createElement("ul");

        for(let j = 1; j <= i; j++){
            let item = document.createElement("li");
            item.textContent = "Elemento " + j;
            lista.appendChild(item);
        }

        contenedor.appendChild(titulo);
        contenedor.appendChild(lista);
    }
}
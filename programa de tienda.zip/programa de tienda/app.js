// Arreglo de productos (camisas)
let camisas = [
    { nombre: "Camisa blanca", precio: 200, cantidad: 5 },
    { nombre: "Camisa negra", precio: 250, cantidad: 3 },
    { nombre: "Camisa azul", precio: 180, cantidad: 0 }
];

// Mostrar menú
function mostrarMenu() {
    return parseInt(prompt(`
        Opciones disponibles
        1.- Ver camisas
        2.- Comprar camisa
        3.- Salir
        Elige una opción:
    `));
}

// Ver camisas disponibles
function verCamisas() {
    let mensaje = "Lista de camisas:\n";

    camisas.forEach((camisa, index) => {
        mensaje += `${index + 1}.- ${camisa.nombre} - $${camisa.precio} - `;
        
        if (camisa.cantidad > 0) {
            mensaje += `Disponibles: ${camisa.cantidad}\n`;
        } else {
            mensaje += `No hay camisas disponibles\n`;
        }
    });

    alert(mensaje);
}

// Comprar camisa
function comprarCamisa() {
    let numero = parseInt(prompt("Ingresa el número de la camisa que deseas comprar:"));

    if (numero > 0 && numero <= camisas.length) {
        let camisa = camisas[numero - 1];

        if (camisa.cantidad > 0) {
            camisa.cantidad--;
            alert(`Compraste: ${camisa.nombre}\nQuedan: ${camisa.cantidad}`);
        } else {
            alert("Ya no hay camisas disponibles de este tipo");
        }
    } else {
        alert("Número inválido");
    }
}

// Función principal
function iniciarPrograma() {
    let bandera = true;

    while (bandera) {
        let opcion = mostrarMenu();

        switch (opcion) {
            case 1:
                verCamisas();
                break;
            case 2:
                comprarCamisa();
                break;
            case 3:
                bandera = false;
                alert("Saliendo del programa");
                break;
            default:
                alert("Opción no válida");
        }
    }
}

// Ejecutar programa
iniciarPrograma();
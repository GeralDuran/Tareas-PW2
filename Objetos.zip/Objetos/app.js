let alumno = {
    id: 321315153,
    nombre: "Evelin",
    primerApellido: "Granados",
    segundoApellido: "Duran",
    edad: 20,
    titulado: false,
    egresado: {
        estado: false, 
        promedio: "8.9",
        semestre: "Sexto semestre",
        turno: "Matutino",
        materiasDeber: "1"
    },
    domicilio: {
        calle: "Ignacio M. Altamirano",
        numero: "8",
        colonia: "Miguel Hidalgo",
        cp: "13200", 
        alcaldia: "Tlahuac",
        estado: "CDMX",
        pais: "México",
        continenete: "Latinoamérica"
    },
    kinder: {
        nombre: "Ana Maria Gallaga",
        actividadPrimerdia: function () {
            console.log("jugar a la casita");
        },
        actividadRecurrente: function () {
            console.log("Dibujar");
        },
        datosMiss: {
            nombre: "María",
            edad: 29,
            estudios: "Licenciatura"
        }
    },
    primaria: {
        nombre: "Jaime Torres Bodet",
        comer(comida) {
            return `ahora está comiendo ${comida}`;
        },
        mensaje(mensajeAlumno) {
            return `${this.nombre} es la Primaria y el alumno tiene que ir a ${mensajeAlumno}`;
        }
    },
    secundaria: {
        nombre: "Tlahuizcalli",
        hace(tarea) {
            return `ahora está haciendo tarea de ${tarea}`;
        },
        mensaje(suspencion) {
            return `${this.nombre} es la secundaria y esta suspendido por ${suspencion}`;
        }
    },
     preparatoria: {
        nombre: "cch oriente",
        viernes(salida) {
            return `ahora está en ${salida}`;
        },
        debe(mat) {
            return `${this.nombre} debe esta materia ${mat}`;
        }
    }
}
console.log(alumno.kinder.datosMiss.nombre);
console.log(alumno.primaria.mensaje("Direccion"));
console.log(alumno.primaria.comer("Galleta"));
console.log(alumno.secundaria.hace("Historia"));
console.log(alumno.secundaria.mensaje("1 semana"));
console.log(alumno.preparatoria.viernes("Pasillos"));
console.log(alumno.preparatoria.debe("TLRIID"));

